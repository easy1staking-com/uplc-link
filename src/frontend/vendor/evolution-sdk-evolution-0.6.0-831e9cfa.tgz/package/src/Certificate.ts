/**
 * Certificate types and schemas for Cardano Conway-era transactions.
 *
 * @module Certificate
 * @since 2.0.0
 */
import { Either as E, Equal, FastCheck, Hash, Inspectable, ParseResult, Schema } from "effect"

import * as Anchor from "./Anchor.js"
import * as CBOR from "./CBOR.js"
import * as Coin from "./Coin.js"
import * as Credential from "./Credential.js"
import * as DRep from "./DRep.js"
import * as EpochNo from "./EpochNo.js"
import * as PoolKeyHash from "./PoolKeyHash.js"
import * as PoolMetadata from "./PoolMetadata.js"
import * as PoolParams from "./PoolParams.js"
import * as Relay from "./Relay.js"
import * as UnitInterval from "./UnitInterval.js"

/**
 * Register a stake credential (CDDL: stake_registration = 0).
 *
 * @since 2.0.0
 * @category certificate
 */
export class StakeRegistration extends Schema.TaggedClass<StakeRegistration>("StakeRegistration")("StakeRegistration", {
  stakeCredential: Credential.Credential
}) {
  toJSON() {
    return {
      _tag: "StakeRegistration" as const,
      stakeCredential: this.stakeCredential.toJSON()
    }
  }

  toString(): string {
    return Inspectable.format(this.toJSON())
  }

  [Inspectable.NodeInspectSymbol](): unknown {
    return this.toJSON()
  }

  [Equal.symbol](that: unknown): boolean {
    return that instanceof StakeRegistration && Equal.equals(this.stakeCredential, that.stakeCredential)
  }

  [Hash.symbol](): number {
    return Hash.cached(this, Hash.combine(Hash.hash("StakeRegistration"))(Hash.hash(this.stakeCredential)))
  }
}

/**
 * Deregister a stake credential (CDDL: stake_deregistration = 1).
 *
 * @since 2.0.0
 * @category certificate
 */
export class StakeDeregistration extends Schema.TaggedClass<StakeDeregistration>("StakeDeregistration")(
  "StakeDeregistration",
  {
    stakeCredential: Credential.Credential
  }
) {
  toJSON() {
    return {
      _tag: "StakeDeregistration" as const,
      stakeCredential: this.stakeCredential.toJSON()
    }
  }

  toString(): string {
    return Inspectable.format(this.toJSON())
  }

  [Inspectable.NodeInspectSymbol](): unknown {
    return this.toJSON()
  }

  [Equal.symbol](that: unknown): boolean {
    return that instanceof StakeDeregistration && Equal.equals(this.stakeCredential, that.stakeCredential)
  }

  [Hash.symbol](): number {
    return Hash.cached(this, Hash.combine(Hash.hash("StakeDeregistration"))(Hash.hash(this.stakeCredential)))
  }
}

/**
 * Delegate stake to a pool (CDDL: stake_delegation = 2).
 *
 * @since 2.0.0
 * @category certificate
 */
export class StakeDelegation extends Schema.TaggedClass<StakeDelegation>("StakeDelegation")("StakeDelegation", {
  stakeCredential: Credential.Credential,
  poolKeyHash: PoolKeyHash.PoolKeyHash
}) {
  toJSON() {
    return {
      _tag: "StakeDelegation" as const,
      stakeCredential: this.stakeCredential.toJSON(),
      poolKeyHash: this.poolKeyHash.toJSON()
    }
  }

  toString(): string {
    return Inspectable.format(this.toJSON())
  }

  [Inspectable.NodeInspectSymbol](): unknown {
    return this.toJSON()
  }

  [Equal.symbol](that: unknown): boolean {
    return (
      that instanceof StakeDelegation &&
      Equal.equals(this.stakeCredential, that.stakeCredential) &&
      Equal.equals(this.poolKeyHash, that.poolKeyHash)
    )
  }

  [Hash.symbol](): number {
    return Hash.cached(
      this,
      Hash.combine(Hash.hash("StakeDelegation"))(
        Hash.combine(Hash.hash(this.stakeCredential))(Hash.hash(this.poolKeyHash))
      )
    )
  }
}

/**
 * Register a stake pool (CDDL: pool_registration = 3).
 *
 * @since 2.0.0
 * @category certificate
 */
export class PoolRegistration extends Schema.TaggedClass<PoolRegistration>("PoolRegistration")("PoolRegistration", {
  poolParams: PoolParams.PoolParams
}) {
  toJSON() {
    return {
      _tag: "PoolRegistration" as const,
      poolParams: this.poolParams.toJSON()
    }
  }

  toString(): string {
    return Inspectable.format(this.toJSON())
  }

  [Inspectable.NodeInspectSymbol](): unknown {
    return this.toJSON()
  }

  [Equal.symbol](that: unknown): boolean {
    return that instanceof PoolRegistration && Equal.equals(this.poolParams, that.poolParams)
  }

  [Hash.symbol](): number {
    return Hash.cached(this, Hash.combine(Hash.hash("PoolRegistration"))(Hash.hash(this.poolParams)))
  }
}

/**
 * Retire a stake pool at a given epoch (CDDL: pool_retirement = 4).
 *
 * @since 2.0.0
 * @category certificate
 */
export class PoolRetirement extends Schema.TaggedClass<PoolRetirement>("PoolRetirement")("PoolRetirement", {
  poolKeyHash: PoolKeyHash.PoolKeyHash,
  epoch: EpochNo.EpochNoSchema
}) {
  toJSON() {
    return {
      _tag: "PoolRetirement" as const,
      poolKeyHash: this.poolKeyHash.toJSON(),
      epoch: this.epoch.toString()
    }
  }

  toString(): string {
    return Inspectable.format(this.toJSON())
  }

  [Inspectable.NodeInspectSymbol](): unknown {
    return this.toJSON()
  }

  [Equal.symbol](that: unknown): boolean {
    return (
      that instanceof PoolRetirement &&
      Equal.equals(this.poolKeyHash, that.poolKeyHash) &&
      Equal.equals(this.epoch, that.epoch)
    )
  }

  [Hash.symbol](): number {
    return Hash.cached(
      this,
      Hash.combine(Hash.hash("PoolRetirement"))(Hash.combine(Hash.hash(this.poolKeyHash))(Hash.hash(this.epoch)))
    )
  }
}

/**
 * Conway-era stake registration with deposit (CDDL: reg_cert = 7).
 *
 * @since 2.0.0
 * @category certificate
 */
export class RegCert extends Schema.TaggedClass<RegCert>("RegCert")("RegCert", {
  stakeCredential: Credential.Credential,
  coin: Coin.Coin
}) {
  toJSON() {
    return {
      _tag: "RegCert" as const,
      stakeCredential: this.stakeCredential.toJSON(),
      coin: this.coin.toString()
    }
  }

  toString(): string {
    return Inspectable.format(this.toJSON())
  }

  [Inspectable.NodeInspectSymbol](): unknown {
    return this.toJSON()
  }

  [Equal.symbol](that: unknown): boolean {
    return (
      that instanceof RegCert &&
      Equal.equals(this.stakeCredential, that.stakeCredential) &&
      Equal.equals(this.coin, that.coin)
    )
  }

  [Hash.symbol](): number {
    return Hash.cached(
      this,
      Hash.combine(Hash.hash("RegCert"))(Hash.combine(Hash.hash(this.stakeCredential))(Hash.hash(this.coin)))
    )
  }
}

/**
 * Conway-era stake deregistration with deposit refund (CDDL: unreg_cert = 8).
 *
 * @since 2.0.0
 * @category certificate
 */
export class UnregCert extends Schema.TaggedClass<UnregCert>("UnregCert")("UnregCert", {
  stakeCredential: Credential.Credential,
  coin: Coin.Coin
}) {
  toJSON() {
    return {
      _tag: "UnregCert" as const,
      stakeCredential: this.stakeCredential.toJSON(),
      coin: this.coin.toString()
    }
  }

  toString(): string {
    return Inspectable.format(this.toJSON())
  }

  [Inspectable.NodeInspectSymbol](): unknown {
    return this.toJSON()
  }

  [Equal.symbol](that: unknown): boolean {
    return (
      that instanceof UnregCert &&
      Equal.equals(this.stakeCredential, that.stakeCredential) &&
      Equal.equals(this.coin, that.coin)
    )
  }

  [Hash.symbol](): number {
    return Hash.cached(
      this,
      Hash.combine(Hash.hash("UnregCert"))(Hash.combine(Hash.hash(this.stakeCredential))(Hash.hash(this.coin)))
    )
  }
}

/**
 * Delegate voting rights to a DRep (CDDL: vote_deleg_cert = 9).
 *
 * @since 2.0.0
 * @category certificate
 */
export class VoteDelegCert extends Schema.TaggedClass<VoteDelegCert>("VoteDelegCert")("VoteDelegCert", {
  stakeCredential: Credential.Credential,
  drep: DRep.DRep
}) {
  toJSON() {
    return {
      _tag: "VoteDelegCert" as const,
      stakeCredential: this.stakeCredential.toJSON(),
      drep: this.drep
    }
  }

  toString(): string {
    return Inspectable.format(this.toJSON())
  }

  [Inspectable.NodeInspectSymbol](): unknown {
    return this.toJSON()
  }

  [Equal.symbol](that: unknown): boolean {
    return (
      that instanceof VoteDelegCert &&
      Equal.equals(this.stakeCredential, that.stakeCredential) &&
      Equal.equals(this.drep, that.drep)
    )
  }

  [Hash.symbol](): number {
    return Hash.cached(
      this,
      Hash.combine(Hash.hash("VoteDelegCert"))(Hash.combine(Hash.hash(this.stakeCredential))(Hash.hash(this.drep)))
    )
  }
}

/**
 * Delegate stake to a pool and voting rights to a DRep (CDDL: stake_vote_deleg_cert = 10).
 *
 * @since 2.0.0
 * @category certificate
 */
export class StakeVoteDelegCert extends Schema.TaggedClass<StakeVoteDelegCert>("StakeVoteDelegCert")(
  "StakeVoteDelegCert",
  {
    stakeCredential: Credential.Credential,
    poolKeyHash: PoolKeyHash.PoolKeyHash,
    drep: DRep.DRep
  }
) {
  toJSON() {
    return {
      _tag: "StakeVoteDelegCert" as const,
      stakeCredential: this.stakeCredential.toJSON(),
      poolKeyHash: this.poolKeyHash.toJSON(),
      drep: this.drep
    }
  }

  toString(): string {
    return Inspectable.format(this.toJSON())
  }

  [Inspectable.NodeInspectSymbol](): unknown {
    return this.toJSON()
  }

  [Equal.symbol](that: unknown): boolean {
    return (
      that instanceof StakeVoteDelegCert &&
      Equal.equals(this.stakeCredential, that.stakeCredential) &&
      Equal.equals(this.poolKeyHash, that.poolKeyHash) &&
      Equal.equals(this.drep, that.drep)
    )
  }

  [Hash.symbol](): number {
    return Hash.cached(
      this,
      Hash.combine(Hash.hash("StakeVoteDelegCert"))(
        Hash.combine(Hash.hash(this.stakeCredential))(Hash.combine(Hash.hash(this.poolKeyHash))(Hash.hash(this.drep)))
      )
    )
  }
}

/**
 * Register stake and delegate to a pool in one certificate (CDDL: stake_reg_deleg_cert = 11).
 *
 * @since 2.0.0
 * @category certificate
 */
export class StakeRegDelegCert extends Schema.TaggedClass<StakeRegDelegCert>("StakeRegDelegCert")("StakeRegDelegCert", {
  stakeCredential: Credential.Credential,
  poolKeyHash: PoolKeyHash.PoolKeyHash,
  coin: Coin.Coin
}) {
  toJSON() {
    return {
      _tag: "StakeRegDelegCert" as const,
      stakeCredential: this.stakeCredential.toJSON(),
      poolKeyHash: this.poolKeyHash.toJSON(),
      coin: this.coin.toString()
    }
  }

  toString(): string {
    return Inspectable.format(this.toJSON())
  }

  [Inspectable.NodeInspectSymbol](): unknown {
    return this.toJSON()
  }

  [Equal.symbol](that: unknown): boolean {
    return (
      that instanceof StakeRegDelegCert &&
      Equal.equals(this.stakeCredential, that.stakeCredential) &&
      Equal.equals(this.poolKeyHash, that.poolKeyHash) &&
      Equal.equals(this.coin, that.coin)
    )
  }

  [Hash.symbol](): number {
    return Hash.cached(
      this,
      Hash.combine(Hash.hash("StakeRegDelegCert"))(
        Hash.combine(Hash.hash(this.stakeCredential))(Hash.combine(Hash.hash(this.poolKeyHash))(Hash.hash(this.coin)))
      )
    )
  }
}

/**
 * Register stake and delegate voting rights to a DRep (CDDL: vote_reg_deleg_cert = 12).
 *
 * @since 2.0.0
 * @category certificate
 */
export class VoteRegDelegCert extends Schema.TaggedClass<VoteRegDelegCert>("VoteRegDelegCert")("VoteRegDelegCert", {
  stakeCredential: Credential.Credential,
  drep: DRep.DRep,
  coin: Coin.Coin
}) {
  toJSON() {
    return {
      _tag: "VoteRegDelegCert" as const,
      stakeCredential: this.stakeCredential.toJSON(),
      drep: this.drep,
      coin: this.coin.toString()
    }
  }

  toString(): string {
    return Inspectable.format(this.toJSON())
  }

  [Inspectable.NodeInspectSymbol](): unknown {
    return this.toJSON()
  }

  [Equal.symbol](that: unknown): boolean {
    return (
      that instanceof VoteRegDelegCert &&
      Equal.equals(this.stakeCredential, that.stakeCredential) &&
      Equal.equals(this.drep, that.drep) &&
      Equal.equals(this.coin, that.coin)
    )
  }

  [Hash.symbol](): number {
    return Hash.cached(
      this,
      Hash.combine(Hash.hash("VoteRegDelegCert"))(
        Hash.combine(Hash.hash(this.stakeCredential))(Hash.combine(Hash.hash(this.drep))(Hash.hash(this.coin)))
      )
    )
  }
}

/**
 * Register stake, delegate to a pool, and delegate voting rights to a DRep (CDDL: stake_vote_reg_deleg_cert = 13).
 *
 * @since 2.0.0
 * @category certificate
 */
export class StakeVoteRegDelegCert extends Schema.TaggedClass<StakeVoteRegDelegCert>("StakeVoteRegDelegCert")(
  "StakeVoteRegDelegCert",
  {
    stakeCredential: Credential.Credential,
    poolKeyHash: PoolKeyHash.PoolKeyHash,
    drep: DRep.DRep,
    coin: Coin.Coin
  }
) {
  toJSON() {
    return {
      _tag: "StakeVoteRegDelegCert" as const,
      stakeCredential: this.stakeCredential.toJSON(),
      poolKeyHash: this.poolKeyHash.toJSON(),
      drep: this.drep,
      coin: this.coin.toString()
    }
  }

  toString(): string {
    return Inspectable.format(this.toJSON())
  }

  [Inspectable.NodeInspectSymbol](): unknown {
    return this.toJSON()
  }

  [Equal.symbol](that: unknown): boolean {
    return (
      that instanceof StakeVoteRegDelegCert &&
      Equal.equals(this.stakeCredential, that.stakeCredential) &&
      Equal.equals(this.poolKeyHash, that.poolKeyHash) &&
      Equal.equals(this.drep, that.drep) &&
      Equal.equals(this.coin, that.coin)
    )
  }

  [Hash.symbol](): number {
    return Hash.cached(
      this,
      Hash.combine(Hash.hash("StakeVoteRegDelegCert"))(
        Hash.combine(Hash.hash(this.stakeCredential))(
          Hash.combine(Hash.hash(this.poolKeyHash))(Hash.combine(Hash.hash(this.drep))(Hash.hash(this.coin)))
        )
      )
    )
  }
}

/**
 * Authorize a committee hot credential (CDDL: auth_committee_hot_cert = 14).
 *
 * @since 2.0.0
 * @category certificate
 */
export class AuthCommitteeHotCert extends Schema.TaggedClass<AuthCommitteeHotCert>("AuthCommitteeHotCert")(
  "AuthCommitteeHotCert",
  {
    committeeColdCredential: Credential.Credential,
    committeeHotCredential: Credential.Credential
  }
) {
  toJSON() {
    return {
      _tag: "AuthCommitteeHotCert" as const,
      committeeColdCredential: this.committeeColdCredential.toJSON(),
      committeeHotCredential: this.committeeHotCredential.toJSON()
    }
  }

  toString(): string {
    return Inspectable.format(this.toJSON())
  }

  [Inspectable.NodeInspectSymbol](): unknown {
    return this.toJSON()
  }

  [Equal.symbol](that: unknown): boolean {
    return (
      that instanceof AuthCommitteeHotCert &&
      Equal.equals(this.committeeColdCredential, that.committeeColdCredential) &&
      Equal.equals(this.committeeHotCredential, that.committeeHotCredential)
    )
  }

  [Hash.symbol](): number {
    return Hash.cached(
      this,
      Hash.combine(Hash.hash("AuthCommitteeHotCert"))(
        Hash.combine(Hash.hash(this.committeeColdCredential))(Hash.hash(this.committeeHotCredential))
      )
    )
  }
}

/**
 * Resign a committee cold credential (CDDL: resign_committee_cold_cert = 15).
 *
 * @since 2.0.0
 * @category certificate
 */
export class ResignCommitteeColdCert extends Schema.TaggedClass<ResignCommitteeColdCert>("ResignCommitteeColdCert")(
  "ResignCommitteeColdCert",
  {
    committeeColdCredential: Credential.Credential,
    anchor: Schema.NullishOr(Anchor.Anchor)
  }
) {
  toJSON() {
    return {
      _tag: "ResignCommitteeColdCert" as const,
      committeeColdCredential: this.committeeColdCredential.toJSON(),
      anchor: this.anchor
    }
  }

  toString(): string {
    return Inspectable.format(this.toJSON())
  }

  [Inspectable.NodeInspectSymbol](): unknown {
    return this.toJSON()
  }

  [Equal.symbol](that: unknown): boolean {
    return (
      that instanceof ResignCommitteeColdCert &&
      Equal.equals(this.committeeColdCredential, that.committeeColdCredential) &&
      Equal.equals(this.anchor, that.anchor)
    )
  }

  [Hash.symbol](): number {
    return Hash.cached(
      this,
      Hash.combine(Hash.hash("ResignCommitteeColdCert"))(
        Hash.combine(Hash.hash(this.committeeColdCredential))(Hash.hash(this.anchor))
      )
    )
  }
}

/**
 * Register as a DRep (CDDL: reg_drep_cert = 16).
 *
 * @since 2.0.0
 * @category certificate
 */
export class RegDrepCert extends Schema.TaggedClass<RegDrepCert>("RegDrepCert")("RegDrepCert", {
  drepCredential: Credential.Credential,
  coin: Coin.Coin,
  anchor: Schema.NullishOr(Anchor.Anchor)
}) {
  toJSON() {
    return {
      _tag: "RegDrepCert" as const,
      drepCredential: this.drepCredential.toJSON(),
      coin: this.coin.toString(),
      anchor: this.anchor
    }
  }

  toString(): string {
    return Inspectable.format(this.toJSON())
  }

  [Inspectable.NodeInspectSymbol](): unknown {
    return this.toJSON()
  }

  [Equal.symbol](that: unknown): boolean {
    return (
      that instanceof RegDrepCert &&
      Equal.equals(this.drepCredential, that.drepCredential) &&
      Equal.equals(this.coin, that.coin) &&
      Equal.equals(this.anchor, that.anchor)
    )
  }

  [Hash.symbol](): number {
    return Hash.cached(
      this,
      Hash.combine(Hash.hash("RegDrepCert"))(
        Hash.combine(Hash.hash(this.drepCredential))(Hash.combine(Hash.hash(this.coin))(Hash.hash(this.anchor)))
      )
    )
  }
}

/**
 * Unregister as a DRep (CDDL: unreg_drep_cert = 17).
 *
 * @since 2.0.0
 * @category certificate
 */
export class UnregDrepCert extends Schema.TaggedClass<UnregDrepCert>("UnregDrepCert")("UnregDrepCert", {
  drepCredential: Credential.Credential,
  coin: Coin.Coin
}) {
  toJSON() {
    return {
      _tag: "UnregDrepCert" as const,
      drepCredential: this.drepCredential.toJSON(),
      coin: this.coin.toString()
    }
  }

  toString(): string {
    return Inspectable.format(this.toJSON())
  }

  [Inspectable.NodeInspectSymbol](): unknown {
    return this.toJSON()
  }

  [Equal.symbol](that: unknown): boolean {
    return (
      that instanceof UnregDrepCert &&
      Equal.equals(this.drepCredential, that.drepCredential) &&
      Equal.equals(this.coin, that.coin)
    )
  }

  [Hash.symbol](): number {
    return Hash.cached(
      this,
      Hash.combine(Hash.hash("UnregDrepCert"))(Hash.combine(Hash.hash(this.drepCredential))(Hash.hash(this.coin)))
    )
  }
}

/**
 * Update DRep metadata anchor (CDDL: update_drep_cert = 18).
 *
 * @since 2.0.0
 * @category certificate
 */
export class UpdateDrepCert extends Schema.TaggedClass<UpdateDrepCert>("UpdateDrepCert")("UpdateDrepCert", {
  drepCredential: Credential.Credential,
  anchor: Schema.NullishOr(Anchor.Anchor)
}) {
  toJSON() {
    return {
      _tag: "UpdateDrepCert" as const,
      drepCredential: this.drepCredential.toJSON(),
      anchor: this.anchor
    }
  }

  toString(): string {
    return Inspectable.format(this.toJSON())
  }

  [Inspectable.NodeInspectSymbol](): unknown {
    return this.toJSON()
  }

  [Equal.symbol](that: unknown): boolean {
    return (
      that instanceof UpdateDrepCert &&
      Equal.equals(this.drepCredential, that.drepCredential) &&
      Equal.equals(this.anchor, that.anchor)
    )
  }

  [Hash.symbol](): number {
    return Hash.cached(
      this,
      Hash.combine(Hash.hash("UpdateDrepCert"))(Hash.combine(Hash.hash(this.drepCredential))(Hash.hash(this.anchor)))
    )
  }
}

/**
 * Certificate union schema based on Conway CDDL specification
 *
 * CDDL: certificate =
 *   [
 *   stake_registration
 *   // stake_deregistration
 *   // stake_delegation
 *   // pool_registration
 *   // pool_retirement
 *   // reg_cert
 *   // unreg_cert
 *   // vote_deleg_cert
 *   // stake_vote_deleg_cert
 *   // stake_reg_deleg_cert
 *   // vote_reg_deleg_cert
 *   // stake_vote_reg_deleg_cert
 *   // auth_committee_hot_cert
 *   // resign_committee_cold_cert
 *   // reg_drep_cert
 *   // unreg_drep_cert
 *   // update_drep_cert
 *   ]
 *
 * stake_registration = (0, stake_credential)
 * stake_deregistration = (1, stake_credential)
 * stake_delegation = (2, stake_credential, pool_keyhash)
 * pool_registration = (3, pool_params)
 * pool_retirement = (4, pool_keyhash, epoch_no)
 * reg_cert = (7, stake_credential, coin)
 * unreg_cert = (8, stake_credential, coin)
 * vote_deleg_cert = (9, stake_credential, drep)
 * stake_vote_deleg_cert = (10, stake_credential, pool_keyhash, drep)
 * stake_reg_deleg_cert = (11, stake_credential, pool_keyhash, coin)
 * vote_reg_deleg_cert = (12, stake_credential, drep, coin)
 * stake_vote_reg_deleg_cert = (13, stake_credential, pool_keyhash, drep, coin)
 * auth_committee_hot_cert = (14, committee_cold_credential, committee_hot_credential)
 * resign_committee_cold_cert = (15, committee_cold_credential, anchor/ nil)
 * reg_drep_cert = (16, drep_credential, coin, anchor/ nil)
 * unreg_drep_cert = (17, drep_credential, coin)
 * update_drep_cert = (18, drep_credential, anchor/ nil)
 *
 * @since 2.0.0
 * @category schemas
 */
export const Certificate = Schema.Union(
  // 0: stake_registration = (0, stake_credential)
  StakeRegistration,
  // 1: stake_deregistration = (1, stake_credential)
  StakeDeregistration,
  // 2: stake_delegation = (2, stake_credential, pool_keyhash)
  StakeDelegation,
  // 3: pool_registration = (3, pool_params)
  PoolRegistration,
  // 4: pool_retirement = (4, pool_keyhash, epoch_no)
  PoolRetirement,
  // 7: reg_cert = (7, stake_credential, coin)
  RegCert,
  // 8: unreg_cert = (8, stake_credential, coin)
  UnregCert,
  // 9: vote_deleg_cert = (9, stake_credential, drep)
  VoteDelegCert,
  // 10: stake_vote_deleg_cert = (10, stake_credential, pool_keyhash, drep)
  StakeVoteDelegCert,
  // 11: stake_reg_deleg_cert = (11, stake_credential, pool_keyhash, coin)
  StakeRegDelegCert,
  // 12: vote_reg_deleg_cert = (12, stake_credential, drep, coin)
  VoteRegDelegCert,
  // 13: stake_vote_reg_deleg_cert = (13, stake_credential, pool_keyhash, drep, coin)
  StakeVoteRegDelegCert,
  // 14: auth_committee_hot_cert = (14, committee_cold_credential, committee_hot_credential)
  AuthCommitteeHotCert,
  // 15: resign_committee_cold_cert = (15, committee_cold_credential, anchor/ nil)
  ResignCommitteeColdCert,
  // 16: reg_drep_cert = (16, drep_credential, coin, anchor/ nil)
  RegDrepCert,
  // 17: unreg_drep_cert = (17, drep_credential, coin)
  UnregDrepCert,
  // 18: update_drep_cert = (18, drep_credential, anchor/ nil)
  UpdateDrepCert
)

export const CDDLSchema = Schema.Union(
  // 0: stake_registration = (0, stake_credential)
  Schema.Tuple(Schema.Literal(0n), Credential.CDDLSchema),
  // 1: stake_deregistration = (1, stake_credential)
  Schema.Tuple(Schema.Literal(1n), Credential.CDDLSchema),
  // 2: stake_delegation = (2, stake_credential, pool_keyhash)
  Schema.Tuple(Schema.Literal(2n), Credential.CDDLSchema, CBOR.ByteArray),
  // 3: pool_registration = (3, pool_params)
  Schema.Tuple(
    Schema.Literal(3n),
    // Flattened PoolParams.CDDLSchema
    CBOR.ByteArray, // operator (pool_keyhash as bytes)
    CBOR.ByteArray, // vrf_keyhash (as bytes)
    CBOR.Integer, // pledge (coin)
    CBOR.Integer, // cost (coin)
    UnitInterval.CDDLSchema, // margin
    CBOR.ByteArray, // reward_account (bytes)
    Schema.Array(CBOR.ByteArray), // pool_owners (array of addr_keyhash bytes)
    Schema.Array(Schema.encodedSchema(Relay.FromCDDL)), // relays
    Schema.NullOr(Schema.encodedSchema(PoolMetadata.FromCDDL)) // pool_metadata
  ),
  // 4: pool_retirement = (4, pool_keyhash, epoch_no)
  Schema.Tuple(Schema.Literal(4n), CBOR.ByteArray, CBOR.Integer),
  // 7: reg_cert = (7, stake_credential , coin)
  Schema.Tuple(Schema.Literal(7n), Credential.CDDLSchema, CBOR.Integer),
  // 8: unreg_cert = (8, stake_credential, coin)
  Schema.Tuple(Schema.Literal(8n), Credential.CDDLSchema, CBOR.Integer),
  // 9: vote_deleg_cert = (9, stake_credential, drep)
  Schema.Tuple(Schema.Literal(9n), Credential.CDDLSchema, DRep.CDDLSchema),
  // 10: stake_vote_deleg_cert = (10, stake_credential, pool_keyhash, drep)
  Schema.Tuple(Schema.Literal(10n), Credential.CDDLSchema, CBOR.ByteArray, DRep.CDDLSchema),
  // 11: stake_reg_deleg_cert = (11, stake_credential, pool_keyhash, coin)
  Schema.Tuple(Schema.Literal(11n), Credential.CDDLSchema, CBOR.ByteArray, CBOR.Integer),
  // 12: vote_reg_deleg_cert = (12, stake_credential, drep, coin)
  Schema.Tuple(Schema.Literal(12n), Credential.CDDLSchema, DRep.CDDLSchema, CBOR.Integer),
  // 13: stake_vote_reg_deleg_cert = (13, stake_credential, pool_keyhash, drep, coin)
  Schema.Tuple(Schema.Literal(13n), Credential.CDDLSchema, CBOR.ByteArray, DRep.CDDLSchema, CBOR.Integer),
  // 14: auth_committee_hot_cert = (14, committee_cold_credential, committee_hot_credential)
  Schema.Tuple(Schema.Literal(14n), Credential.CDDLSchema, Credential.CDDLSchema),
  // 15: resign_committee_cold_cert = (15, committee_cold_credential, anchor/ nil)
  Schema.Tuple(Schema.Literal(15n), Credential.CDDLSchema, Schema.NullishOr(Anchor.CDDLSchema)),
  // 16: reg_drep_cert = (16, drep_credential, coin, anchor/ nil)
  Schema.Tuple(Schema.Literal(16n), Credential.CDDLSchema, CBOR.Integer, Schema.NullishOr(Anchor.CDDLSchema)),
  // 17: unreg_drep_cert = (17, drep_credential, coin)
  Schema.Tuple(Schema.Literal(17n), Credential.CDDLSchema, CBOR.Integer),
  // 18: update_drep_cert = (18, drep_credential, anchor/ nil)
  Schema.Tuple(Schema.Literal(18n), Credential.CDDLSchema, Schema.NullishOr(Anchor.CDDLSchema))
)

/**
 * CDDL schema for Certificate based on Conway specification.
 *
 * Transforms between CBOR tuple representation and Certificate union.
 * Each certificate type is encoded as [type_id, ...fields]
 *
 * @since 2.0.0
 * @category schemas
 */
export const FromCDDL = Schema.transformOrFail(CDDLSchema, Schema.typeSchema(Certificate), {
  strict: true,
  encode: (toA) =>
    E.gen(function* () {
      switch (toA._tag) {
        case "StakeRegistration": {
          const credentialCDDL = yield* ParseResult.encodeEither(Credential.FromCDDL)(toA.stakeCredential)
          return [0n, credentialCDDL] as const
        }
        case "StakeDeregistration": {
          const credentialCDDL = yield* ParseResult.encodeEither(Credential.FromCDDL)(toA.stakeCredential)
          return [1n, credentialCDDL] as const
        }
        case "StakeDelegation": {
          const credentialCDDL = yield* ParseResult.encodeEither(Credential.FromCDDL)(toA.stakeCredential)
          const poolKeyHashBytes = yield* ParseResult.encodeEither(PoolKeyHash.FromBytes)(toA.poolKeyHash)
          return [2n, credentialCDDL, poolKeyHashBytes] as const
        }
        case "PoolRegistration": {
          const poolParamsCDDL = yield* ParseResult.encodeEither(PoolParams.FromCDDL)(toA.poolParams)
          // Spread encoded PoolParams fields directly into the certificate tuple (flattening)
          return [3n, ...poolParamsCDDL] as const
        }
        case "PoolRetirement": {
          const poolKeyHashBytes = yield* ParseResult.encodeEither(PoolKeyHash.FromBytes)(toA.poolKeyHash)
          return [4n, poolKeyHashBytes, BigInt(toA.epoch)] as const
        }
        case "RegCert": {
          const credentialCDDL = yield* ParseResult.encodeEither(Credential.FromCDDL)(toA.stakeCredential)
          return [7n, credentialCDDL, toA.coin] as const
        }
        case "UnregCert": {
          const credentialCDDL = yield* ParseResult.encodeEither(Credential.FromCDDL)(toA.stakeCredential)
          return [8n, credentialCDDL, toA.coin] as const
        }
        case "VoteDelegCert": {
          const credentialCDDL = yield* ParseResult.encodeEither(Credential.FromCDDL)(toA.stakeCredential)
          const drepCDDL = yield* ParseResult.encodeEither(DRep.FromCDDL)(toA.drep)
          return [9n, credentialCDDL, drepCDDL] as const
        }
        case "StakeVoteDelegCert": {
          const credentialCDDL = yield* ParseResult.encodeEither(Credential.FromCDDL)(toA.stakeCredential)
          const poolKeyHashBytes = yield* ParseResult.encodeEither(PoolKeyHash.FromBytes)(toA.poolKeyHash)
          const drepCDDL = yield* ParseResult.encodeEither(DRep.FromCDDL)(toA.drep)
          return [10n, credentialCDDL, poolKeyHashBytes, drepCDDL] as const
        }
        case "StakeRegDelegCert": {
          const credentialCDDL = yield* ParseResult.encodeEither(Credential.FromCDDL)(toA.stakeCredential)
          const poolKeyHashBytes = yield* ParseResult.encodeEither(PoolKeyHash.FromBytes)(toA.poolKeyHash)
          return [11n, credentialCDDL, poolKeyHashBytes, toA.coin] as const
        }
        case "VoteRegDelegCert": {
          const credentialCDDL = yield* ParseResult.encodeEither(Credential.FromCDDL)(toA.stakeCredential)
          const drepCDDL = yield* ParseResult.encodeEither(DRep.FromCDDL)(toA.drep)
          return [12n, credentialCDDL, drepCDDL, toA.coin] as const
        }
        case "StakeVoteRegDelegCert": {
          const credentialCDDL = yield* ParseResult.encodeEither(Credential.FromCDDL)(toA.stakeCredential)
          const poolKeyHashBytes = yield* ParseResult.encodeEither(PoolKeyHash.FromBytes)(toA.poolKeyHash)
          const drepCDDL = yield* ParseResult.encodeEither(DRep.FromCDDL)(toA.drep)
          return [13n, credentialCDDL, poolKeyHashBytes, drepCDDL, toA.coin] as const
        }
        case "AuthCommitteeHotCert": {
          const coldCredentialCDDL = yield* ParseResult.encodeEither(Credential.FromCDDL)(toA.committeeColdCredential)
          const hotCredentialCDDL = yield* ParseResult.encodeEither(Credential.FromCDDL)(toA.committeeHotCredential)
          return [14n, coldCredentialCDDL, hotCredentialCDDL] as const
        }
        case "ResignCommitteeColdCert": {
          const credentialCDDL = yield* ParseResult.encodeEither(Credential.FromCDDL)(toA.committeeColdCredential)
          const anchorCDDL = toA.anchor ? yield* ParseResult.encodeEither(Anchor.FromCDDL)(toA.anchor) : null
          return [15n, credentialCDDL, anchorCDDL] as const
        }
        case "RegDrepCert": {
          const credentialCDDL = yield* ParseResult.encodeEither(Credential.FromCDDL)(toA.drepCredential)
          const anchorCDDL = toA.anchor ? yield* ParseResult.encodeEither(Anchor.FromCDDL)(toA.anchor) : null
          return [16n, credentialCDDL, toA.coin, anchorCDDL] as const
        }
        case "UnregDrepCert": {
          const credentialCDDL = yield* ParseResult.encodeEither(Credential.FromCDDL)(toA.drepCredential)
          return [17n, credentialCDDL, toA.coin] as const
        }
        case "UpdateDrepCert": {
          const credentialCDDL = yield* ParseResult.encodeEither(Credential.FromCDDL)(toA.drepCredential)
          const anchorCDDL = toA.anchor ? yield* ParseResult.encodeEither(Anchor.FromCDDL)(toA.anchor) : null
          return [18n, credentialCDDL, anchorCDDL] as const
        }
        // default:
        //   return yield* ParseResult.fail(
        //     new ParseResult.Type(CDDLSchema.ast, toA, `Unsupported certificate type: ${(toA as any)._tag}`)
        //   )
      }
    }),
  decode: (fromA) =>
    E.gen(function* () {
      // const [typeId, ...fields] = fromA

      switch (fromA[0]) {
        case 0n: {
          // stake_registration = (0, stake_credential)
          // const [credentialCDDL] = fields
          const [, credentialCDDL] = fromA
          const stakeCredential = yield* ParseResult.decodeEither(Credential.FromCDDL)(credentialCDDL)
          return new StakeRegistration({ stakeCredential }, { disableValidation: true })
        }
        case 1n: {
          // stake_deregistration = (1, stake_credential)
          const [, credentialCDDL] = fromA
          const stakeCredential = yield* ParseResult.decodeEither(Credential.FromCDDL)(credentialCDDL)
          return new StakeDeregistration({ stakeCredential }, { disableValidation: true })
        }
        case 2n: {
          // stake_delegation = (2, stake_credential, pool_keyhash)
          const [, credentialCDDL, poolKeyHashBytes] = fromA
          const stakeCredential = yield* ParseResult.decodeEither(Credential.FromCDDL)(credentialCDDL)
          const poolKeyHash = yield* ParseResult.decodeEither(PoolKeyHash.FromBytes)(poolKeyHashBytes)
          return new StakeDelegation({ stakeCredential, poolKeyHash }, { disableValidation: true })
        }
        case 3n: {
          // pool_registration = (3, ...pool_params fields flattened)
          const [
            ,
            operatorBytes,
            vrfKeyhashBytes,
            pledge,
            cost,
            marginEncoded,
            rewardAccountBytes,
            poolOwnersBytes,
            relaysEncoded,
            poolMetadataEncoded
          ] = fromA as unknown as readonly [
            3n,
            Uint8Array,
            Uint8Array,
            bigint,
            bigint,
            unknown,
            Uint8Array,
            ReadonlyArray<Uint8Array>,
            ReadonlyArray<unknown>,
            unknown | null
          ]
          const poolParams = yield* ParseResult.decodeEither(PoolParams.FromCDDL)([
            operatorBytes,
            vrfKeyhashBytes,
            pledge,
            cost,
            marginEncoded as any,
            rewardAccountBytes,
            poolOwnersBytes as any,
            relaysEncoded as any,
            poolMetadataEncoded as any
          ] as any)
          return new PoolRegistration({ poolParams }, { disableValidation: true })
        }
        case 4n: {
          // pool_retirement = (4, pool_keyhash, epoch_no)
          const [, poolKeyHashBytes, epochBigInt] = fromA
          const poolKeyHash = yield* ParseResult.decodeEither(PoolKeyHash.FromBytes)(poolKeyHashBytes)
          const epoch = epochBigInt as EpochNo.EpochNo
          return new PoolRetirement({ poolKeyHash, epoch }, { disableValidation: true })
        }
        case 7n: {
          // reg_cert = (7, stake_credential, coin)
          const [, credentialCDDL, coinBigInt] = fromA
          const stakeCredential = yield* ParseResult.decodeEither(Credential.FromCDDL)(credentialCDDL)
          const coin = yield* ParseResult.decodeEither(Schema.typeSchema(Coin.Coin))(coinBigInt)
          return new RegCert({ stakeCredential, coin }, { disableValidation: true })
        }
        case 8n: {
          // unreg_cert = (8, stake_credential, coin)
          const [, credentialCDDL, coinBigInt] = fromA
          const stakeCredential = yield* ParseResult.decodeEither(Credential.FromCDDL)(credentialCDDL)
          const coin = yield* ParseResult.decodeEither(Schema.typeSchema(Coin.Coin))(coinBigInt)
          return new UnregCert({ stakeCredential, coin }, { disableValidation: true })
        }
        case 9n: {
          // vote_deleg_cert = (9, stake_credential, drep)
          const [, credentialCDDL, drepCDDL] = fromA
          const stakeCredential = yield* ParseResult.decodeEither(Credential.FromCDDL)(credentialCDDL)
          const drep = yield* ParseResult.decodeEither(DRep.FromCDDL)(drepCDDL)
          return new VoteDelegCert({ stakeCredential, drep }, { disableValidation: true })
        }
        case 10n: {
          // stake_vote_deleg_cert = (10, stake_credential, pool_keyhash, drep)
          const [, credentialCDDL, poolKeyHashBytes, drepCDDL] = fromA
          const stakeCredential = yield* ParseResult.decodeEither(Credential.FromCDDL)(credentialCDDL)
          const poolKeyHash = yield* ParseResult.decodeEither(PoolKeyHash.FromBytes)(poolKeyHashBytes)
          const drep = yield* ParseResult.decodeEither(DRep.FromCDDL)(drepCDDL)
          return new StakeVoteDelegCert(
            {
              stakeCredential,
              poolKeyHash,
              drep
            },
            { disableValidation: true }
          )
        }
        case 11n: {
          // stake_reg_deleg_cert = (11, stake_credential, pool_keyhash, coin)
          const [, credentialCDDL, poolKeyHashBytes, coinBigInt] = fromA
          const stakeCredential = yield* ParseResult.decodeEither(Credential.FromCDDL)(credentialCDDL)
          const poolKeyHash = yield* ParseResult.decodeEither(PoolKeyHash.FromBytes)(poolKeyHashBytes)
          const coin = yield* ParseResult.decodeEither(Schema.typeSchema(Coin.Coin))(coinBigInt)
          return new StakeRegDelegCert(
            {
              stakeCredential,
              poolKeyHash,
              coin
            },
            { disableValidation: true }
          )
        }
        case 12n: {
          // vote_reg_deleg_cert = (12, stake_credential, drep, coin)
          const [, credentialCDDL, drepCDDL, coinBigInt] = fromA
          const stakeCredential = yield* ParseResult.decodeEither(Credential.FromCDDL)(credentialCDDL)
          const drep = yield* ParseResult.decodeEither(DRep.FromCDDL)(drepCDDL)
          const coin = yield* ParseResult.decodeEither(Schema.typeSchema(Coin.Coin))(coinBigInt)
          return new VoteRegDelegCert({ stakeCredential, drep, coin }, { disableValidation: true })
        }
        case 13n: {
          // stake_vote_reg_deleg_cert = (13, stake_credential, pool_keyhash, drep, coin)
          const [, credentialCDDL, poolKeyHashBytes, drepCDDL, coinBigInt] = fromA
          const stakeCredential = yield* ParseResult.decodeEither(Credential.FromCDDL)(credentialCDDL)
          const poolKeyHash = yield* ParseResult.decodeEither(PoolKeyHash.FromBytes)(poolKeyHashBytes)
          const drep = yield* ParseResult.decodeEither(DRep.FromCDDL)(drepCDDL)
          const coin = yield* ParseResult.decodeEither(Schema.typeSchema(Coin.Coin))(coinBigInt)
          return new StakeVoteRegDelegCert(
            {
              stakeCredential,
              poolKeyHash,
              drep,
              coin
            },
            { disableValidation: true }
          )
        }
        case 14n: {
          // auth_committee_hot_cert = (14, committee_cold_credential, committee_hot_credential)
          const [, coldCredentialCDDL, hotCredentialCDDL] = fromA
          const committeeColdCredential = yield* ParseResult.decodeEither(Credential.FromCDDL)(coldCredentialCDDL)
          const committeeHotCredential = yield* ParseResult.decodeEither(Credential.FromCDDL)(hotCredentialCDDL)
          return new AuthCommitteeHotCert(
            {
              committeeColdCredential,
              committeeHotCredential
            },
            { disableValidation: true }
          )
        }
        case 15n: {
          // resign_committee_cold_cert = (15, committee_cold_credential, anchor/ nil)
          const [, credentialCDDL, anchorCDDL] = fromA
          const committeeColdCredential = yield* ParseResult.decodeEither(Credential.FromCDDL)(credentialCDDL)
          const anchor = anchorCDDL ? yield* ParseResult.decodeEither(Anchor.FromCDDL)(anchorCDDL) : undefined
          return new ResignCommitteeColdCert(
            {
              committeeColdCredential,
              anchor
            },
            { disableValidation: true }
          )
        }
        case 16n: {
          // reg_drep_cert = (16, drep_credential, coin, anchor/ nil)
          const [, credentialCDDL, coinBigInt, anchorCDDL] = fromA
          const drepCredential = yield* ParseResult.decodeEither(Credential.FromCDDL)(credentialCDDL)
          const coin = yield* ParseResult.decodeEither(Schema.typeSchema(Coin.Coin))(coinBigInt)
          const anchor = anchorCDDL ? yield* ParseResult.decodeEither(Anchor.FromCDDL)(anchorCDDL) : undefined
          return new RegDrepCert({ drepCredential, coin, anchor }, { disableValidation: true })
        }
        case 17n: {
          // unreg_drep_cert = (17, drep_credential, coin)
          const [, credentialCDDL, coinBigInt] = fromA
          const drepCredential = yield* ParseResult.decodeEither(Credential.FromCDDL)(credentialCDDL)
          const coin = yield* ParseResult.decodeEither(Schema.typeSchema(Coin.Coin))(coinBigInt)
          return new UnregDrepCert({ drepCredential, coin }, { disableValidation: true })
        }
        case 18n: {
          // update_drep_cert = (18, drep_credential, anchor/ nil)
          const [, credentialCDDL, anchorCDDL] = fromA
          const drepCredential = yield* ParseResult.decodeEither(Credential.FromCDDL)(credentialCDDL)
          const anchor = anchorCDDL ? yield* ParseResult.decodeEither(Anchor.FromCDDL)(anchorCDDL) : undefined
          return new UpdateDrepCert({ drepCredential, anchor }, { disableValidation: true })
        }
        // default:
        //   return yield* ParseResult.fail(
        //     new ParseResult.Type(CDDLSchema.ast, fromA, `Unsupported certificate type ID: ${fromA}`)
        //   )
      }
    })
})

/**
 * CBOR bytes transformation schema for Certificate.
 *
 * @since 2.0.0
 * @category schemas
 */
export const FromCBORBytes = (options: CBOR.CodecOptions = CBOR.CML_DEFAULT_OPTIONS) =>
  Schema.compose(
    CBOR.FromBytes(options), // Uint8Array → CBOR
    FromCDDL // CBOR → Certificate
  )

/**
 * CBOR hex transformation schema for Certificate.
 *
 * @since 2.0.0
 * @category schemas
 */
export const FromCBORHex = (options: CBOR.CodecOptions = CBOR.CML_DEFAULT_OPTIONS) =>
  Schema.compose(
    Schema.Uint8ArrayFromHex, // string → Uint8Array
    FromCBORBytes(options) // Uint8Array → Certificate
  )

/**
 * Type alias for Certificate.
 *
 * @since 2.0.0
 * @category model
 */
export type Certificate = typeof Certificate.Type

/**
 * Check if the given value is a valid Certificate.
 *
 * @since 2.0.0
 * @category predicates
 */
export const is = Schema.is(Certificate)

/**
 * FastCheck arbitrary for Certificate instances.
 *
 * @since 2.0.0
 * @category testing
 */
export const arbitrary = FastCheck.oneof(
  // StakeRegistration
  Credential.arbitrary.map((stakeCredential) => new StakeRegistration({ stakeCredential })),
  // StakeDeregistration
  Credential.arbitrary.map((stakeCredential) => new StakeDeregistration({ stakeCredential })),
  // StakeDelegation
  FastCheck.tuple(Credential.arbitrary, PoolKeyHash.arbitrary).map(
    ([stakeCredential, poolKeyHash]) => new StakeDelegation({ stakeCredential, poolKeyHash })
  ),
  // PoolRegistration
  PoolParams.arbitrary.map((poolParams) => new PoolRegistration({ poolParams })),
  // PoolRetirement
  FastCheck.tuple(PoolKeyHash.arbitrary, EpochNo.generator).map(
    ([poolKeyHash, epoch]) => new PoolRetirement({ poolKeyHash, epoch: epoch as EpochNo.EpochNo })
  ),
  // RegCert
  FastCheck.tuple(Credential.arbitrary, Coin.arbitrary).map(
    ([stakeCredential, coin]) => new RegCert({ stakeCredential, coin })
  ),
  // UnregCert
  FastCheck.tuple(Credential.arbitrary, Coin.arbitrary).map(
    ([stakeCredential, coin]) => new UnregCert({ stakeCredential, coin })
  ),
  // VoteDelegCert
  FastCheck.tuple(Credential.arbitrary, DRep.arbitrary).map(
    ([stakeCredential, drep]) => new VoteDelegCert({ stakeCredential, drep })
  ),
  // StakeVoteDelegCert
  FastCheck.tuple(Credential.arbitrary, PoolKeyHash.arbitrary, DRep.arbitrary).map(
    ([stakeCredential, poolKeyHash, drep]) => new StakeVoteDelegCert({ stakeCredential, poolKeyHash, drep })
  ),
  // StakeRegDelegCert
  FastCheck.tuple(Credential.arbitrary, PoolKeyHash.arbitrary, Coin.arbitrary).map(
    ([stakeCredential, poolKeyHash, coin]) => new StakeRegDelegCert({ stakeCredential, poolKeyHash, coin })
  ),
  // VoteRegDelegCert
  FastCheck.tuple(Credential.arbitrary, DRep.arbitrary, Coin.arbitrary).map(
    ([stakeCredential, drep, coin]) => new VoteRegDelegCert({ stakeCredential, drep, coin })
  ),
  // StakeVoteRegDelegCert
  FastCheck.tuple(Credential.arbitrary, PoolKeyHash.arbitrary, DRep.arbitrary, Coin.arbitrary).map(
    ([stakeCredential, poolKeyHash, drep, coin]) =>
      new StakeVoteRegDelegCert({ stakeCredential, poolKeyHash, drep, coin })
  ),
  // AuthCommitteeHotCert
  FastCheck.tuple(Credential.arbitrary, Credential.arbitrary).map(
    ([committeeColdCredential, committeeHotCredential]) =>
      new AuthCommitteeHotCert({ committeeColdCredential, committeeHotCredential })
  ),
  // ResignCommitteeColdCert
  FastCheck.tuple(Credential.arbitrary, FastCheck.option(Anchor.arbitrary, { nil: undefined })).map(
    ([committeeColdCredential, anchor]) => new ResignCommitteeColdCert({ committeeColdCredential, anchor })
  ),
  // RegDrepCert
  FastCheck.tuple(Credential.arbitrary, Coin.arbitrary, FastCheck.option(Anchor.arbitrary, { nil: undefined })).map(
    ([drepCredential, coin, anchor]) => new RegDrepCert({ drepCredential, coin, anchor })
  ),
  // UnregDrepCert
  FastCheck.tuple(Credential.arbitrary, Coin.arbitrary).map(
    ([drepCredential, coin]) => new UnregDrepCert({ drepCredential, coin })
  ),
  // UpdateDrepCert
  FastCheck.tuple(Credential.arbitrary, FastCheck.option(Anchor.arbitrary, { nil: undefined })).map(
    ([drepCredential, anchor]) => new UpdateDrepCert({ drepCredential, anchor })
  )
)

/**
 * Parse a Certificate from CBOR bytes.
 *
 * @since 2.0.0
 * @category parsing
 */
export const fromCBORBytes = (bytes: Uint8Array, options?: CBOR.CodecOptions): Certificate =>
  Schema.decodeSync(FromCBORBytes(options))(bytes)

/**
 * Parse a Certificate from CBOR hex string.
 *
 * @since 2.0.0
 * @category parsing
 */
export const fromCBORHex = (hex: string, options?: CBOR.CodecOptions): Certificate =>
  Schema.decodeSync(FromCBORHex(options))(hex)

/**
 * Convert a Certificate to CBOR bytes.
 *
 * @since 2.0.0
 * @category encoding
 */
export const toCBORBytes = (certificate: Certificate, options?: CBOR.CodecOptions): Uint8Array =>
  Schema.encodeSync(FromCBORBytes(options))(certificate)

/**
 * Convert a Certificate to CBOR hex string.
 *
 * @since 2.0.0
 * @category encoding
 */
export const toCBORHex = (certificate: Certificate, options?: CBOR.CodecOptions): string =>
  Schema.encodeSync(FromCBORHex(options))(certificate)
